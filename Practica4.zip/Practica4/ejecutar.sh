#!/bin/bash

# Script de ejecución del programa

escena="Calle"
python3 Panoramas.py "Escenas/$escena" "resultados/$escena"